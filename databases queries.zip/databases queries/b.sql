select publishers.id, publishers.name
from publishers
right join 
   (
    select publishers_id
    from series
    where country_id = 56
   )
   as table_2 
on publishers.id = table_2.publishers_id