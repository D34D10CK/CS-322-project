select distinct first_name, last_name
from people
where id in 
( 
    select stories_colors.person_id
    from stories_colors, stories_pencils, stories_script
    where stories_colors.person_id=stories_pencils.penson_id and stories_pencils.penson_id=stories_script.person_id
               and stories_colors.story_id=stories_pencils.story_id and stories_pencils.story_id=stories_script.story_id
)