select brand_groups.name
from brand_groups
inner join
(
select count(country_id) as number_of_belgium, publisher_id
from
(
select country_id, publisher_id
from indicia_publishers
where country_id = 20
)
having number_of_belgium = max(number_of_belgium)

)
as table_1
on brand_groups.publisher_id = table_1.publisher_id
