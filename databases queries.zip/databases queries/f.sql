select distinct title
from stories
where id in (
          select origin_id
          from 
          (select distinct origin_id, count(origin_id)
          from story_reprints
          group by origin_id
          order by count(origin_id) desc
          limit 10))