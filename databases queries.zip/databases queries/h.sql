select distinct id, title
from stories
where feature like '%Batman%'
        and
        id not in(
	    select distinct id
        from stories
        where feature like '%Batman%')
        and
        id not in (
        select distinct origin_id
        from story_reprints)
        
		