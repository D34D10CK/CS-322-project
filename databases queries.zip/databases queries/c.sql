select name
from series
where country_id=204 and publication_type_id=2;
