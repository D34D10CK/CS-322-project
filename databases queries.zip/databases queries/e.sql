select count(id)
from series
inner join
(
select publisher_id
from indicia_publishers
where name like '%DC comics%'
)
as table1
on series.publisher_id=table1.publisher_id