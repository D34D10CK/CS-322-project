select number
from issues
where publication_date >=1990
order by publication_date